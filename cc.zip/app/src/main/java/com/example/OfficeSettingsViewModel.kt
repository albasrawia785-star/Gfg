package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel الخاص بإدارة إعدادات بيانات المكتب (OfficeSettingsViewModel)
 */
class OfficeSettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: OfficeRepository = OfficeRepositoryImpl(
        SettingsManager.getInstance(application)
    )

    private val _officeInfo = MutableStateFlow(repository.getOfficeInfo())
    val officeInfo: StateFlow<OfficeInfo> = _officeInfo.asStateFlow()

    fun updateOfficeInfo(officeName: String, phone: String) {
        val newInfo = OfficeInfo(officeName = officeName, phone = phone)
        repository.saveOfficeInfo(newInfo)
        _officeInfo.value = newInfo
    }

    fun refreshOfficeInfo() {
        _officeInfo.value = repository.getOfficeInfo()
    }
}
