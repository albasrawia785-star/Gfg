package com.example

import android.content.Context
import android.graphics.*

/**
 * RealEstateContractRenderer: محرك رسم عقد بيع وشراء الدور والأراضي السكنية والزراعية
 * مطابق بنسبة 100% للصورة الأصلية مع كافة التفاصيل والإحداثيات.
 */
class RealEstateContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? RealEstateContract ?: RealEstateContract()

        val margin = 50f
        val fullWidth = A4_WIDTH - (margin * 2)

        // 1. صور الفلل/العقارات في أعلى الهيدر
        val leftVillaRect = RectF(margin, 50f, margin + 200f, 180f)
        val rightVillaRect = RectF(A4_WIDTH - margin - 200f, 50f, A4_WIDTH - margin, 180f)
        drawOptionalHeaderImage(canvas, context, "ic_real_estate_left", leftVillaRect)
        drawOptionalHeaderImage(canvas, context, "ic_real_estate_right", rightVillaRect)

        // مربع رقم العقد تحت الصورة اليسرى
        val noRect = RectF(margin, 185f, margin + 160f, 220f)
        val noBorder = Paint().apply {
            color = COLOR_PRIMARY
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawRoundRect(noRect, 6f, 6f, noBorder)

        val noPaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("NO: ${data.contractNo.ifEmpty { "0025" }}", noRect.centerX(), noRect.centerY() + 7f, noPaint)

        // بيانات المكتب والترويسة الرسمية
        val officeNameText = officeInfo.officeName.ifEmpty { "مكتب السلام للعقارات والسيارات" }
        val officePhoneText = "هاتف: ${officeInfo.phone.ifEmpty { "07700000000" }}"

        val officeNamePaint = Paint().apply {
            color = Color.parseColor("#0F172A") // كحلي داكن فاخر
            textSize = 32f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val officePhonePaint = Paint().apply {
            color = Color.parseColor("#047857") // أخضر رسمي
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText(officeNameText, A4_WIDTH / 2f, 75f, officeNamePaint)
        canvas.drawText(officePhoneText, A4_WIDTH / 2f, 105f, officePhonePaint)

        // نصوص العنوان الرئيسي باللون الأخضر والأحمر
        val mainTitlePaint = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 40f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val subTitlePaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText("عقــد بيع وشــراء", A4_WIDTH / 2f, 145f, mainTitlePaint)
        canvas.drawText("الدور والاراضي السكنية والزراعية", A4_WIDTH / 2f, 178f, subTitlePaint)

        // 2. مربعي الطرف الأول (البائع) والطرف الثاني (المشتري)
        var currentY = 220f
        val boxHeight = 240f
        val (rightBox, leftBox) = drawSideBySidePartyBoxes(
            canvas = canvas,
            topY = currentY,
            boxHeight = boxHeight,
            rightTitle = "الطرف الأول ( البائع )",
            leftTitle = "الطرف الثاني ( المشتري )"
        )

        // محتوى البائع (لون أحمر للـ Labels)
        val redLabelPaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        var rY = rightBox.top + 65f
        val rRight = rightBox.right - 15f
        val rWidth = rightBox.width() - 30f
        drawFieldWithDotsCustomLabel(canvas, "البائع :", data.sellerName, rRight, rY, rWidth, redLabelPaint)
        rY += 38f
        drawFieldWithDotsCustomLabel(canvas, "العنوان :", data.sellerAddress, rRight, rY, rWidth, redLabelPaint)
        rY += 38f
        drawFieldWithDotsCustomLabel(canvas, "رقم الهوية :", data.sellerIdNumber, rRight, rY, rWidth, redLabelPaint)
        rY += 38f
        drawFieldWithDotsCustomLabel(canvas, "الهاتف :", data.sellerPhone, rRight, rY, rWidth, redLabelPaint)

        // محتوى المشتري (لون أخضر للـ Labels)
        val greenLabelPaint = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        var lY = leftBox.top + 65f
        val lRight = leftBox.right - 15f
        val lWidth = leftBox.width() - 30f
        drawFieldWithDotsCustomLabel(canvas, "المشتري :", data.buyerName, lRight, lY, lWidth, greenLabelPaint)
        lY += 38f
        drawFieldWithDotsCustomLabel(canvas, "العنوان :", data.buyerAddress, lRight, lY, lWidth, greenLabelPaint)
        lY += 38f
        drawFieldWithDotsCustomLabel(canvas, "رقم الهوية :", data.buyerIdNumber, lRight, lY, lWidth, greenLabelPaint)
        lY += 38f
        drawFieldWithDotsCustomLabel(canvas, "الهاتف :", data.buyerPhone, lRight, lY, lWidth, greenLabelPaint)

        // 3. نصوص العقد والشروط المالية والتفاصيل
        currentY += boxHeight + 45f

        val introGreenPaint = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("لقد تم الاتفاق بين الطرفين على انعقاد هذا العقد وبالشروط الآتية :", A4_WIDTH - margin, currentY, introGreenPaint)
        currentY += 42f

        // أولا - أ
        val clauseTitleRed = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        val textA = "أولاً - أ - يعترف الطرف الأول ( البائع ) بأنه قد باع للطرف الثاني ( المشتري ) الملك المفصل فيما يلي ."
        canvas.drawText(textA, A4_WIDTH - margin, currentY, clauseTitleRed)
        currentY += 45f

        // نوع الملك | المساحة
        drawFieldWithDots(canvas, "نوع الملك :", data.propertyType, A4_WIDTH - margin, currentY, fullWidth * 0.55f)
        drawFieldWithDots(canvas, "المساحة :", data.propertyArea, A4_WIDTH - margin - (fullWidth * 0.55f), currentY, fullWidth * 0.45f)
        currentY += 48f

        // الرقم والتسلسل | المحلة
        drawFieldWithDots(canvas, "الرقم والتسلسل :", data.plotSequenceNo, A4_WIDTH - margin, currentY, fullWidth * 0.55f)
        drawFieldWithDots(canvas, "المحلة :", data.neighborhood, A4_WIDTH - margin - (fullWidth * 0.55f), currentY, fullWidth * 0.45f)
        currentY += 48f

        // ب . بدل البيع المتفق عليه
        drawFieldWithDots(canvas, "ب . بدل البيع المتفق عليه :", data.totalPrice, A4_WIDTH - margin, currentY, fullWidth - 80f)
        canvas.drawText("دينار", margin + 10f, currentY, bodyTextPaint)
        currentY += 48f

        // ج . العربون الذي تم قبضه
        drawFieldWithDots(canvas, "ج . العربون الذي تم قبضه :", data.depositPrice, A4_WIDTH - margin, currentY, fullWidth - 80f)
        canvas.drawText("دينار", margin + 10f, currentY, bodyTextPaint)
        currentY += 48f

        // الباقي
        drawFieldWithDots(canvas, "الباقي :", data.remainingPrice, A4_WIDTH - margin, currentY, fullWidth - 80f)
        canvas.drawText("دينار", margin + 10f, currentY, bodyTextPaint)
        currentY += 50f

        // د . إذا امتنع الطرف الأول
        canvas.drawText("د . إذا امتنع الطرف الأول ( البائع ) عن إجراء التقرير أو نكل عن البيع بأي صورة كانت فإنه ملزم بإعادة العربون", A4_WIDTH - margin, currentY, clauseTitleRed)
        currentY += 38f
        drawFieldWithDots(canvas, "ويتعهد بدفع تضمينات إلى الطرف الثاني ( المشتري ) قدرها :", data.penaltySellerAmount, A4_WIDTH - margin, currentY, fullWidth - 80f)
        canvas.drawText("دينار", margin + 10f, currentY, bodyTextPaint)
        currentY += 48f

        // ثانيا - يعترف الطرف الثاني
        canvas.drawText("ثانياً - يعترف الطرف الثاني ( المشتري ) بأنه قد قبل الشراء وفي حالة عدم التقرير أو النكول عن الشراء وتأدية قصور البدل", A4_WIDTH - margin, currentY, clauseTitleRed)
        currentY += 38f
        drawFieldWithDots(canvas, "فإنه يتعهد بتأدية تضمينات إلى الطرف الأول ( البائع ) قدرها :", data.penaltyBuyerAmount, A4_WIDTH - margin, currentY, fullWidth - 80f)
        canvas.drawText("دينار", margin + 10f, currentY, bodyTextPaint)
        currentY += 48f

        // ثالثا ورابعا وخامسا
        val items = listOf(
            "ثالثاً - يحق للطرف (الثاني) المشتري تقرير الملك لمن يشاء .",
            "رابعاً - كل مكاتبة غير مختومة بختم المكتب تعتبر باطلة ولا يُعتد بها .",
            "خامساً - لا تُسترجع الدلالية عند حصول أي خلاف بين الطرفين بعد إبرام العقد .",
            "ملاحظات - نسبة الدلالية ٢% والمكتب غير مسؤول بعد التقرير عن الفقرات الإضافية ."
        )
        for (item in items) {
            canvas.drawText(item, A4_WIDTH - margin, currentY, clauseTitleRed)
            currentY += 42f
        }

        // تاريخ وقرار العقد
        currentY += 15f
        val decisionText = "فبناءً على حصول التراضي والإيجاب والقبول قرر هذا العقد في                بتاريخ    /    / 20"
        canvas.drawText(decisionText, A4_WIDTH - margin, currentY, introGreenPaint)
        currentY += 45f

        // ملاحظات إضافية
        drawFieldWithDots(canvas, "ملاحظات إضافية :", data.additionalNotes, A4_WIDTH - margin, currentY, fullWidth)

        // 4. مربع الأختام وبصمات الإبهام
        val stampY = currentY + 25f
        val stampHeight = 110f
        val stampWidth = (fullWidth - 40f) / 3f

        val stampBoxPaint = Paint().apply {
            color = COLOR_BG_LIGHT
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val stampBorderPaint = Paint().apply {
            color = COLOR_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 1f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            isAntiAlias = true
        }
        val stampTextPaint = Paint().apply {
            color = COLOR_LABEL
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightStamp = RectF(A4_WIDTH - margin - stampWidth, stampY, A4_WIDTH - margin, stampY + stampHeight)
        val middleStamp = RectF(A4_WIDTH - margin - (stampWidth * 2) - 20f, stampY, A4_WIDTH - margin - stampWidth - 20f, stampY + stampHeight)
        val leftStamp = RectF(margin, stampY, margin + stampWidth, stampY + stampHeight)

        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة إبهام البائع", rightStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("ختم المكتب وتوقيع المنظم", middleStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة إبهام المشتري", leftStamp.centerX(), stampY + 65f, stampTextPaint)

        // 5. التواقيع
        val redSigPaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val greenSigPaint = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val sigTitles = listOf("الطرف الأول / البائع", "الشاهد الأول", "الشاهد الثاني", "الطرف الثاني / المشتري")
        val sigY = A4_HEIGHT - 65f
        val colWidth = fullWidth / sigTitles.size

        for (i in sigTitles.indices) {
            val cX = A4_WIDTH - margin - (i * colWidth) - (colWidth / 2f)
            val p = if (i == 0) redSigPaint else if (i == sigTitles.size - 1) greenSigPaint else redSigPaint
            canvas.drawText("...........................", cX, sigY - 25f, dotPaint)
            canvas.drawText(sigTitles[i], cX, sigY, p)
        }
    }

    private fun drawFieldWithDotsCustomLabel(
        canvas: Canvas,
        label: String,
        value: String,
        x: Float,
        y: Float,
        totalWidth: Float,
        customLabelPaint: Paint
    ) {
        var currentX = x
        if (label.isNotEmpty()) {
            canvas.drawText(label, currentX, y, customLabelPaint)
            val labelWidth = customLabelPaint.measureText(label) + 10f
            currentX -= labelWidth
        }
        val dotSpaceWidth = (currentX - (x - totalWidth)).coerceAtLeast(30f)

        if (value.isBlank()) {
            val dots = buildString {
                repeat((dotSpaceWidth / 7f).toInt().coerceAtLeast(4)) { append(".") }
            }
            dotPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(dots, currentX, y, dotPaint)
        } else {
            drawRtlText(
                canvas = canvas,
                text = value,
                x = currentX,
                y = y,
                maxWidth = dotSpaceWidth,
                paint = valuePaint,
                align = Paint.Align.RIGHT
            )
        }
    }
}
