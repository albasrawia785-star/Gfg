package com.example

import android.app.DatePickerDialog
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import java.text.SimpleDateFormat
import java.util.*

/**
 * أدوات تنسيق الأرقام والتواريخ لعقود A4 الرسمية
 */
object FormatUtils {

    /**
     * إرجاع تاريخ اليوم الحالي بتنسيق YYYY/MM/DD (مثال: 2026/07/28)
     */
    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.US)
        return sdf.format(Date())
    }

    /**
     * تنسيق المبالغ المالية بإضافة فوارز الآلاف (مثال: 1000000 -> 1,000,000)
     */
    fun formatMoneyInput(rawInput: String): String {
        if (rawInput.isBlank()) return ""

        // تحويل الأرقام الشرقية/العربية إلى أرقام إنجليزية
        val westernDigitsStr = rawInput.map { ch ->
            when (ch) {
                '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
                '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
                else -> ch
            }
        }.joinToString("")

        // استخراج الصافي للرقم
        val digitsOnly = westernDigitsStr.replace(",", "").replace(" ", "").trim()
        val parsedNumber = digitsOnly.toLongOrNull()

        return if (parsedNumber != null) {
            String.format(Locale.US, "%,d", parsedNumber)
        } else {
            // إذا كان النص يحتوي على أرقام وكلمات (مثل: 1000000 دينار)، يتم تنسيق الأرقام داخله
            westernDigitsStr.replace(Regex("\\d+")) { match ->
                val num = match.value.toLongOrNull()
                if (num != null) String.format(Locale.US, "%,d", num) else match.value
            }
        }
    }
}

/**
 * مكون حقل تاريخ تفاعلي مع تقويم لاختيار التاريخ بسهولة
 */
@Composable
fun DatePickerTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val formattedDate = String.format(Locale.US, "%04d/%02d/%02d", year, month + 1, dayOfMonth)
            onValueChange(formattedDate)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier.testTag(testTag),
        singleLine = true,
        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = "التاريخ") },
        trailingIcon = {
            IconButton(onClick = { datePickerDialog.show() }) {
                Icon(Icons.Default.CalendarMonth, contentDescription = "اختر من التقويم", tint = MaterialTheme.colorScheme.primary)
            }
        }
    )
}
