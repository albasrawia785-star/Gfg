package com.example

import android.content.Context
import android.graphics.*

/**
 * MotorcycleContractRenderer: محرك رسم عقد بيع وشراء الدراجات والتكتك والستوتات
 * مطابق بنسبة 100% للصورة الأصلية مع مراعاة كافة الترتيبات والإحداثيات.
 */
class MotorcycleContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? MotorcycleContract ?: MotorcycleContract()

        // 1. صور الهيدر التوضيحية (يمين ويسار)
        val headerLeftRect = RectF(50f, 50f, 260f, 180f)
        val headerRightRect = RectF(A4_WIDTH - 260f, 50f, A4_WIDTH - 50f, 180f)
        drawOptionalHeaderImage(canvas, context, "ic_motorcycle_header_left", headerLeftRect)
        drawOptionalHeaderImage(canvas, context, "ic_motorcycle_header_right", headerRightRect)

        // 2. بيانات المكتب وترويسة العنوان الرئيسية
        val officeNameText = officeInfo.officeName.ifEmpty { "معرض السلام للدراجات والتكتك" }
        val officePhoneText = "هاتف: ${officeInfo.phone.ifEmpty { "07700000000" }}"

        val officeNamePaint = Paint().apply {
            color = COLOR_PRIMARY
            textSize = 30f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val officePhonePaint = Paint().apply {
            color = COLOR_SECONDARY
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText(officeNameText, A4_WIDTH / 2f, 72f, officeNamePaint)
        canvas.drawText(officePhoneText, A4_WIDTH / 2f, 96f, officePhonePaint)

        val titlePaintLarge = Paint().apply {
            color = COLOR_PRIMARY
            textSize = 36f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val subtitlePaint = Paint().apply {
            color = COLOR_SECONDARY
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقــد بيع وشــراء", A4_WIDTH / 2f, 130f, titlePaintLarge)
        canvas.drawText("الدراجات والتكتك والستوتات", A4_WIDTH / 2f, 162f, subtitlePaint)

        // رقم الوصل
        val noPaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val noText = "№  ${data.contractNo.ifEmpty { "004126" }}"
        canvas.drawText(noText, A4_WIDTH / 2f, 175f, noPaint)

        // 3. مربعي الطرف الأول (البائع) والطرف الثاني (المشتري)
        val topY = 195f
        val boxHeight = 230f
        val (rightBox, leftBox) = drawSideBySidePartyBoxes(
            canvas = canvas,
            topY = topY,
            boxHeight = boxHeight,
            rightTitle = "الطرف الأول ( البائع )",
            leftTitle = "الطرف الثاني ( المشتري )"
        )

        // --- محتوى الطرف الأول (البائع) ---
        var rY = rightBox.top + 60f
        val rRight = rightBox.right - 15f
        val rWidth = rightBox.width() - 30f

        drawFieldWithDots(canvas, "البائع السيد:", data.sellerName, rRight, rY, rWidth)
        rY += 38f
        drawFieldWithDots(canvas, "الساكن:", data.sellerAddress, rRight, rY, rWidth)
        rY += 38f

        // محلة / زقاق / دار
        val subWidth = rWidth / 3f
        drawFieldWithDots(canvas, "محلة:", data.sellerNeighborhood, rRight, rY, subWidth)
        drawFieldWithDots(canvas, "زقاق:", data.sellerAlley, rRight - subWidth, rY, subWidth)
        drawFieldWithDots(canvas, "دار:", data.sellerHouse, rRight - (subWidth * 2), rY, subWidth)
        rY += 38f

        drawFieldWithDots(canvas, "رقم البطاقة الوطنية:", data.sellerIdNumber, rRight, rY, rWidth)
        rY += 38f

        drawFieldWithDots(canvas, "موبايل:", data.sellerPhone, rRight, rY, rWidth)

        // --- محتوى الطرف الثاني (المشتري) ---
        var lY = leftBox.top + 60f
        val lRight = leftBox.right - 15f
        val lWidth = leftBox.width() - 30f

        drawFieldWithDots(canvas, "المشتري السيد:", data.buyerName, lRight, lY, lWidth)
        lY += 38f
        drawFieldWithDots(canvas, "الساكن:", data.buyerAddress, lRight, lY, lWidth)
        lY += 38f

        drawFieldWithDots(canvas, "محلة:", data.buyerNeighborhood, lRight, lY, subWidth)
        drawFieldWithDots(canvas, "زقاق:", data.buyerAlley, lRight - subWidth, lY, subWidth)
        drawFieldWithDots(canvas, "دار:", data.buyerHouse, lRight - (subWidth * 2), lY, subWidth)
        lY += 38f

        drawFieldWithDots(canvas, "رقم البطاقة الوطنية:", data.buyerIdNumber, lRight, lY, lWidth)
        lY += 38f

        drawFieldWithDots(canvas, "موبايل:", data.buyerPhone, lRight, lY, lWidth)

        // 4. أسطر مواصفات المركبة والبدل المالي
        var curY = topY + boxHeight + 40f
        val margin = 50f
        val fullWidth = A4_WIDTH - (margin * 2)

        // السطر 1: الدراجة المرقمة | نوع | موبايل
        val col3Width = fullWidth / 3f
        drawFieldWithDots(canvas, "الدراجة المرقمة :", data.registeredNumber, A4_WIDTH - margin, curY, col3Width)
        drawFieldWithDots(canvas, "نوع :", data.vehicleType, A4_WIDTH - margin - col3Width, curY, col3Width)
        drawFieldWithDots(canvas, "موبايل :", data.contactPhone, A4_WIDTH - margin - (col3Width * 2), curY, col3Width)
        curY += 52f

        // السطر 2: اللون | الحجم | الماركة | رقم المحرك
        val col4Width = fullWidth / 4f
        drawFieldWithDots(canvas, "اللون :", data.color, A4_WIDTH - margin, curY, col4Width)
        drawFieldWithDots(canvas, "الحجم :", data.engineCc, A4_WIDTH - margin - col4Width, curY, col4Width)
        drawFieldWithDots(canvas, "الماركة :", data.brand, A4_WIDTH - margin - (col4Width * 2), curY, col4Width)
        drawFieldWithDots(canvas, "رقم المحرك :", data.engineNumber, A4_WIDTH - margin - (col4Width * 3), curY, col4Width)
        curY += 52f

        // السطر 3: رقم الشاصي
        drawFieldWithDots(canvas, "رقم الشاصي :", data.chassisNumber, A4_WIDTH - margin, curY, fullWidth)
        curY += 52f

        // السطر 4: ببدل قدره
        drawFieldWithDots(canvas, "ببدل قدره :", data.totalPrice, A4_WIDTH - margin, curY, fullWidth)
        curY += 52f

        // السطر 5: وقد قبض البائع مبلغ قدره | والباقي
        drawFieldWithDots(canvas, "وقد قبض البائع مبلغ قدره :", data.paidAmount, A4_WIDTH - margin, curY, fullWidth * 0.6f)
        drawFieldWithDots(canvas, "والباقي :", data.remainingAmount, A4_WIDTH - margin - (fullWidth * 0.6f), curY, fullWidth * 0.4f)
        curY += 52f

        // السطر 6: البائع الحائز | الساكن
        drawFieldWithDots(canvas, "البائع الحائز :", data.possessorName, A4_WIDTH - margin, curY, fullWidth * 0.55f)
        drawFieldWithDots(canvas, "الساكن :", data.possessorAddress, A4_WIDTH - margin - (fullWidth * 0.55f), curY, fullWidth * 0.45f)
        curY += 52f

        // السطر 7: محلة | زقاق | دار | هاتف
        drawFieldWithDots(canvas, "محلة :", data.possessorNeighborhood, A4_WIDTH - margin, curY, col4Width)
        drawFieldWithDots(canvas, "زقاق :", data.possessorAlley, A4_WIDTH - margin - col4Width, curY, col4Width)
        drawFieldWithDots(canvas, "دار :", data.possessorHouse, A4_WIDTH - margin - (col4Width * 2), curY, col4Width)
        drawFieldWithDots(canvas, "هاتف :", data.possessorPhone, A4_WIDTH - margin - (col4Width * 3), curY, col4Width)
        curY += 52f

        // السطر 8: رقم البطاقة الوطنية
        drawFieldWithDots(canvas, "رقم البطاقة الوطنية :", data.possessorIdNumber, A4_WIDTH - margin, curY, fullWidth)
        curY += 52f

        // السطر 9: الملاحظات
        drawFieldWithDots(canvas, "الملاحظات :", data.notes, A4_WIDTH - margin, curY, fullWidth)
        curY += 60f

        // 5. البنود والشروط القانونية
        val sectionBgPaint = Paint().apply {
            color = COLOR_PRIMARY
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val sectionTitlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val sectionRect = RectF(margin, curY, A4_WIDTH - margin, curY + 32f)
        canvas.drawRoundRect(sectionRect, 6f, 6f, sectionBgPaint)
        canvas.drawText("الشروط والبنود القانونية للعقد:", A4_WIDTH - margin - 15f, curY + 22f, sectionTitlePaint)
        curY += 55f

        val clauses = listOf(
            "- المباع لا يرجع ولا يبدل.",
            "- علماً بأني اشتريت الدراجة المرقمة من مالكها الشرعي وقد سددت كامل ثمنها وأتعهد بتسجيلها.",
            "- على البائع والمشتري تسجيل الدراجة حسب قوانين المرور والمعرض غير مسؤول خلاف ذلك.",
            "- الطرف الأول مسؤول عن دفع الغرامات المرورية والكمركية والضرائب وجميع ما يترتب على الدراجة.",
            "- يعتبر هذا الوصل ملغياً بعد تنظيم العقد المروري، وتبلغ الطرفان بمعرفة دار كل منهما."
        )

        val clausePaint = Paint().apply {
            color = COLOR_TEXT
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        for (clause in clauses) {
            canvas.drawText(clause, A4_WIDTH - margin - 10f, curY, clausePaint)
            curY += 46f
        }

        // سطر التاريخ والوقت
        curY += 15f
        val dateText = "نظم هذا الوصل بثلاث نسخ وتعاطيناها تحريرياً في بغداد بتاريخ    /    / 202   في الساعة    "
        canvas.drawText(dateText, A4_WIDTH - margin - 10f, curY, clausePaint)

        // 6. مربع بصمات الأختام
        val stampY = curY + 25f
        val stampHeight = 110f
        val stampWidth = (fullWidth - 40f) / 3f

        val stampBoxPaint = Paint().apply {
            color = COLOR_BG_LIGHT
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val stampBorderPaint = Paint().apply {
            color = COLOR_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 1f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            isAntiAlias = true
        }
        val stampTextPaint = Paint().apply {
            color = COLOR_LABEL
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightStamp = RectF(A4_WIDTH - margin - stampWidth, stampY, A4_WIDTH - margin, stampY + stampHeight)
        val middleStamp = RectF(A4_WIDTH - margin - (stampWidth * 2) - 20f, stampY, A4_WIDTH - margin - stampWidth - 20f, stampY + stampHeight)
        val leftStamp = RectF(margin, stampY, margin + stampWidth, stampY + stampHeight)

        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة إبهام البائع", rightStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("ختم المعرض والتوقيع", middleStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة إبهام المشتري", leftStamp.centerX(), stampY + 65f, stampTextPaint)

        // 7. التواقيع أسفل الورقة
        drawSignatures(
            canvas = canvas,
            titles = listOf("توقيع الطرف الأول (البائع)", "الشاهد", "توقيع الطرف الثاني (المشتري)"),
            bottomY = A4_HEIGHT - 65f
        )
    }
}
