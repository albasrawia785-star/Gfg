package com.example

/**
 * محول قوالب العقود (ContractFormMapper)
 * يقدم تحويلاً ناعماً من كائنات بيانات العقود الخاصة إلى النموذج الموحد ContractFormModel
 * لتنفيذ مبادئ Clean Architecture و SOLID بدون تكرار كود الرسم.
 */
object ContractFormMapper {

    /**
     * تحويل أي كائن عقد إلى ContractFormModel
     */
    fun mapToFormModel(
        contractData: Any,
        contractType: ContractType,
        officeInfo: OfficeInfo
    ): ContractFormModel {
        return when (contractData) {
            is RealEstateContract -> mapRealEstate(contractData, officeInfo)
            is CarSaleContract -> mapCarSale(contractData, officeInfo)
            is RentalContract -> mapRental(contractData, officeInfo)
            is MotorcycleContract -> mapMotorcycle(contractData, officeInfo)
            else -> mapFallback(contractData, contractType)
        }
    }

    private fun mapRealEstate(data: RealEstateContract, officeInfo: OfficeInfo): ContractFormModel {
        val sections = listOf(
            ContractSection(
                title = "الطرف الأول ( البائع )",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("اسم البائع الثلاثي", data.sellerName, 2f),
                        ContractField("رقم الهاتف", data.sellerPhone, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("رقم الهوية / الوطنية", data.sellerIdNumber, 1f),
                        ContractField("عنوان السكن الحالي", data.sellerAddress, 2f)
                    ))
                )
            ),
            ContractSection(
                title = "الطرف الثاني ( المشتري )",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("اسم المشتري الثلاثي", data.buyerName, 2f),
                        ContractField("رقم الهاتف", data.buyerPhone, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("رقم الهوية / الوطنية", data.buyerIdNumber, 1f),
                        ContractField("عنوان السكن الحالي", data.buyerAddress, 2f)
                    ))
                )
            ),
            ContractSection(
                title = "تفاصيل العقار والبيع",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("نوع العقار", data.propertyType, 1f),
                        ContractField("المساحة الإجمالية", if (data.propertyArea.isNotBlank()) "${data.propertyArea} م²" else "", 1f),
                        ContractField("الرقم والتسلسل", data.plotSequenceNo, 1f),
                        ContractField("المحلة / المنطقة", data.neighborhood, 1f)
                    ))
                )
            ),
            ContractSection(
                title = "التفاصيل المالية والبدل المتفق عليه",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("بدل البيع الكلي", if (data.totalPrice.isNotBlank()) "${data.totalPrice} دينار" else "", 1f, isHighlight = true),
                        ContractField("العربون المستلم", if (data.depositPrice.isNotBlank()) "${data.depositPrice} دينار" else "", 1f),
                        ContractField("المبلغ المتبقي", if (data.remainingPrice.isNotBlank()) "${data.remainingPrice} دينار" else "", 1f)
                    ))
                )
            )
        )

        val clauses = mutableListOf<String>()
        if (data.additionalNotes.isNotBlank()) {
            clauses.add("الملاحظات والشروط الإضافية: ${data.additionalNotes}")
        } else {
            clauses.add("يلتزم الطرفان بكافة الشروط والإقرارات القانونية المقرة شرعاً وقانوناً بشأن انتقال الملكية وتفريغ المبيع.")
        }

        val witnessesText = buildString {
            if (data.witness1Name.isNotBlank()) append("الشاهد الأول: ${data.witness1Name}  ")
            if (data.witness2Name.isNotBlank()) append("الشاهد الثاني: ${data.witness2Name}")
        }
        if (witnessesText.isNotBlank()) {
            clauses.add(witnessesText)
        }

        return ContractFormModel(
            contractType = ContractType.REAL_ESTATE,
            title = ContractTemplateManager.getTemplate(ContractType.REAL_ESTATE).title,
            contractNo = data.contractNo,
            contractDate = if (data.contractDate.isNotBlank()) data.contractDate else "____/____/2026",
            sections = sections,
            clauses = clauses,
            signatures = listOf("توقيع الطرف الأول (البائع)", "توقيع الطرف الثاني (المشتري)", "توقيع الشهود", "ختم وتوقيع المكتب")
        )
    }

    private fun mapCarSale(data: CarSaleContract, officeInfo: OfficeInfo): ContractFormModel {
        val sections = listOf(
            ContractSection(
                title = "الطرف الأول ( البائع )",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("اسم البائع الثلاثي", data.sellerName, 2f),
                        ContractField("رقم الهاتف", data.sellerPhone, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("رقم الهوية / الوطنية", data.sellerIdNumber, 1f),
                        ContractField("عنوان السكن", data.sellerAddress, 2f)
                    )),
                    ContractRow(listOf(
                        ContractField("المالك الشرعي للمركبة", data.carLegalOwner, 2f),
                        ContractField("عنوان المالك الشرعي", data.ownerAddress, 2f)
                    ))
                )
            ),
            ContractSection(
                title = "الطرف الثاني ( المشتري )",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("اسم المشتري الثلاثي", data.buyerName, 2f),
                        ContractField("رقم الهاتف", data.buyerPhone, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("رقم الهوية / الوطنية", data.buyerIdNumber, 1f),
                        ContractField("عنوان السكن", data.buyerAddress, 2f)
                    ))
                )
            ),
            ContractSection(
                title = "مواصفات المركبة المباعة",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("نوع الماركة والنوع", data.carBrandAndType, 2f),
                        ContractField("الصنف", data.carCategory, 1f),
                        ContractField("الموديل", data.modelYear, 1f),
                        ContractField("اللون", data.color, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("رقم السنوية / اللوحة", data.annualRegNumber, 1f),
                        ContractField("رقم المحرك", data.engineNumber, 1f),
                        ContractField("رقم الشاسي", data.chassisNumber, 1.5f)
                    ))
                )
            ),
            ContractSection(
                title = "المبالغ المالية والبدل",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("بدل البيع الكلي", if (data.totalPrice.isNotBlank()) "${data.totalPrice} دينار" else "", 1f, isHighlight = true),
                        ContractField("المبلغ المقبوض", if (data.paidAmount.isNotBlank()) "${data.paidAmount} دينار" else "", 1f),
                        ContractField("المبلغ المتبقي", if (data.remainingAmount.isNotBlank()) "${data.remainingAmount} دينار" else "", 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("المبلغ كتابةً", data.totalPriceWords, 1f)
                    ))
                )
            )
        )

        val clauses = mutableListOf<String>()
        val witnessOrganizer = buildString {
            if (data.organizerName.isNotBlank()) append("منظم العقد: ${data.organizerName}  ")
            if (data.witnessName.isNotBlank()) append("الشاهد: ${data.witnessName}")
        }
        if (witnessOrganizer.isNotBlank()) {
            clauses.add(witnessOrganizer)
        }
        clauses.add("أقر الطرفان بمعاينة المركبة واستلامها خالية من أي موانع قانونية أو شواغل.")

        return ContractFormModel(
            contractType = ContractType.CAR_SALE,
            title = ContractTemplateManager.getTemplate(ContractType.CAR_SALE).title,
            contractNo = data.contractNo,
            contractDate = if (data.contractDate.isNotBlank()) data.contractDate else "____/____/2026",
            sections = sections,
            clauses = clauses,
            signatures = listOf("توقيع البائع", "توقيع المشتري", "توقيع منظم العقد / الشاهد", "ختم وتوقيع المعرض")
        )
    }

    private fun mapRental(data: RentalContract, officeInfo: OfficeInfo): ContractFormModel {
        val sections = listOf(
            ContractSection(
                title = "أطراف العقد (المؤجر والمستأجر)",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("اسم المؤجر (الفريق الأول)", data.lessorName, 1f),
                        ContractField("اسم المستأجر (الفريق الثاني)", data.lesseeName, 1f)
                    ))
                )
            ),
            ContractSection(
                title = "تفاصيل العين المؤجرة وموقعها",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("موقع العين المؤجرة", data.propertyLocation, 2f),
                        ContractField("المحلة", data.neighborhood, 1f),
                        ContractField("زقاق / دار", data.alleyNumber, 1f),
                        ContractField("رقم الأبواب", data.doorsNumber, 1f)
                    ))
                )
            ),
            ContractSection(
                title = "مدة الإيجار والبدل المالي",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("مدة الإيجار", data.leaseDuration, 1f),
                        ContractField("تاريخ الابتداء", data.startDate, 1f),
                        ContractField("تاريخ انتهاء الإيجار", data.endDate, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("بدل الإيجار بالأرقام", if (data.rentAmountNumber.isNotBlank()) "${data.rentAmountNumber} دينار" else "", 1f, isHighlight = true),
                        ContractField("بدل الإيجار كتابةً", data.rentAmountWords, 2f)
                    ))
                )
            )
        )

        val clauses = mutableListOf<String>()
        if (data.returnToLesseeText.isNotBlank()) {
            clauses.add("العائد إلى المستأجر: ${data.returnToLesseeText}")
        }
        if (data.additionalClauses.isNotBlank()) {
            clauses.add("الشروط والفقرات الإضافية: ${data.additionalClauses}")
        } else {
            clauses.add("يتعهد المستأجر بالمحافظة على العين المؤجرة وسداد أجور الكهرباء والماء واستخدام المأجور للغرض المخصص له حصراً.")
        }

        val witnesses = buildString {
            if (data.witness1Name.isNotBlank()) append("الشاهد الأول: ${data.witness1Name}  ")
            if (data.witness2Name.isNotBlank()) append("الشاهد الثاني: ${data.witness2Name}")
        }
        if (witnesses.isNotBlank()) {
            clauses.add(witnesses)
        }

        return ContractFormModel(
            contractType = ContractType.RENTAL,
            title = ContractTemplateManager.getTemplate(ContractType.RENTAL).title,
            contractNo = data.contractNo,
            contractDate = if (data.signDate.isNotBlank()) data.signDate else "____/____/2026",
            sections = sections,
            clauses = clauses,
            signatures = listOf("توقيع المؤجر", "توقيع المستأجر", "توقيع الشهود", "توقيع وختم المكتب")
        )
    }

    private fun mapMotorcycle(data: MotorcycleContract, officeInfo: OfficeInfo): ContractFormModel {
        val sections = listOf(
            ContractSection(
                title = "الطرف الأول ( البائع )",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("اسم البائع", data.sellerName, 2f),
                        ContractField("رقم الهاتف", data.sellerPhone, 1f),
                        ContractField("رقم الهوية", data.sellerIdNumber, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("العنوان والمنطقة", data.sellerAddress, 2f),
                        ContractField("المحلة", data.sellerNeighborhood, 1f),
                        ContractField("الزقاق", data.sellerAlley, 1f),
                        ContractField("الدار", data.sellerHouse, 1f)
                    ))
                )
            ),
            ContractSection(
                title = "الطرف الثاني ( المشتري )",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("اسم المشتري", data.buyerName, 2f),
                        ContractField("رقم الهاتف", data.buyerPhone, 1f),
                        ContractField("رقم الهوية", data.buyerIdNumber, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("العنوان والمنطقة", data.buyerAddress, 2f),
                        ContractField("المحلة", data.buyerNeighborhood, 1f),
                        ContractField("الزقاق", data.buyerAlley, 1f),
                        ContractField("الدار", data.buyerHouse, 1f)
                    ))
                )
            ),
            ContractSection(
                title = "مواصفات الدراجة / التكتك / الستوتة",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("نوع المركبة", data.vehicleType, 1f),
                        ContractField("الماركة", data.brand, 1f),
                        ContractField("اللون", data.color, 1f),
                        ContractField("الحجم", data.engineCc, 1f)
                    )),
                    ContractRow(listOf(
                        ContractField("الرقم المسجل", data.registeredNumber, 1f),
                        ContractField("رقم المحرك", data.engineNumber, 1f),
                        ContractField("رقم الشاسي", data.chassisNumber, 1.5f)
                    ))
                )
            ),
            ContractSection(
                title = "البدل المالي والمقبوض",
                rows = listOf(
                    ContractRow(listOf(
                        ContractField("بدل البيع الكلي", if (data.totalPrice.isNotBlank()) "${data.totalPrice} دينار" else "", 1f, isHighlight = true),
                        ContractField("المبلغ المقبوض", if (data.paidAmount.isNotBlank()) "${data.paidAmount} دينار" else "", 1f),
                        ContractField("المبلغ المتبقي", if (data.remainingAmount.isNotBlank()) "${data.remainingAmount} دينار" else "", 1f)
                    ))
                )
            )
        )

        val clauses = mutableListOf<String>()
        if (data.possessorName.isNotBlank()) {
            clauses.add("البائع الحائز: ${data.possessorName} | هاتف: ${data.possessorPhone} | العنوان: ${data.possessorAddress}")
        }
        if (data.notes.isNotBlank()) {
            clauses.add("ملاحظات: ${data.notes}")
        }
        if (data.witnessName.isNotBlank()) {
            clauses.add("الشاهد: ${data.witnessName}")
        }

        return ContractFormModel(
            contractType = ContractType.MOTORCYCLE,
            title = ContractTemplateManager.getTemplate(ContractType.MOTORCYCLE).title,
            contractNo = data.contractNo,
            contractDate = if (data.contractDate.isNotBlank()) "${data.contractDate} ${data.contractTime}" else "____/____/2026",
            sections = sections,
            clauses = clauses,
            signatures = listOf("توقيع البائع", "توقيع المشتري", "توقيع الشاهد", "ختم وتوقيع المكتب")
        )
    }

    private fun mapFallback(data: Any, contractType: ContractType): ContractFormModel {
        return ContractFormModel(
            contractType = contractType,
            title = ContractTemplateManager.getTemplate(contractType).title,
            contractNo = "0001",
            contractDate = "____/____/2026",
            sections = emptyList(),
            clauses = listOf("عقد رسمي موثق"),
            signatures = listOf("توقيع البائع / المؤجر", "توقيع المشتري / المستأجر", "توقيع الشاهد", "توقيع المكتب")
        )
    }
}
