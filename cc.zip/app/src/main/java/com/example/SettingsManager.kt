package com.example

import android.content.Context
import android.content.SharedPreferences

/**
 * مدير إعدادات المكتب / المعرض لحفظ واسترجاع بيانات الترويسة من SharedPreferences
 */
class SettingsManager private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    /**
     * اسم المكتب / المعرض
     */
    var officeName: String
        get() = prefs.getString(KEY_OFFICE_NAME, DEFAULT_OFFICE_NAME) ?: DEFAULT_OFFICE_NAME
        set(value) = prefs.edit().putString(KEY_OFFICE_NAME, value.trim()).apply()

    /**
     * رقم هاتف المكتب / المعرض
     */
    var officePhone: String
        get() = prefs.getString(KEY_OFFICE_PHONE, DEFAULT_OFFICE_PHONE) ?: DEFAULT_OFFICE_PHONE
        set(value) = prefs.edit().putString(KEY_OFFICE_PHONE, value.trim()).apply()

    /**
     * عنوان المكتب / المعرض (اختياري)
     */
    var officeAddress: String
        get() = prefs.getString(KEY_OFFICE_ADDRESS, DEFAULT_OFFICE_ADDRESS) ?: DEFAULT_OFFICE_ADDRESS
        set(value) = prefs.edit().putString(KEY_OFFICE_ADDRESS, value.trim()).apply()

    /**
     * حفظ بيانات المكتب دفعة واحدة
     */
    fun saveOfficeDetails(name: String, phone: String, address: String = "") {
        prefs.edit()
            .putString(KEY_OFFICE_NAME, name.trim())
            .putString(KEY_OFFICE_PHONE, phone.trim())
            .putString(KEY_OFFICE_ADDRESS, address.trim())
            .apply()
    }

    /**
     * استرجاع بيانات المكتب كـ Triple(Name, Phone, Address)
     */
    fun getOfficeDetails(): Triple<String, String, String> {
        return Triple(officeName, officePhone, officeAddress)
    }

    companion object {
        private const val PREF_NAME = "office_settings_preferences"
        const val KEY_OFFICE_NAME = "office_name"
        const val KEY_OFFICE_PHONE = "office_phone"
        const val KEY_OFFICE_ADDRESS = "office_address"

        const val DEFAULT_OFFICE_NAME = "مكتب السلام للعقارات والسيارات"
        const val DEFAULT_OFFICE_PHONE = "07700000000"
        const val DEFAULT_OFFICE_ADDRESS = ""

        @Volatile
        private var INSTANCE: SettingsManager? = null

        fun getInstance(context: Context): SettingsManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
