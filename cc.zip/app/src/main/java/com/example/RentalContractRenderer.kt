package com.example

import android.content.Context
import android.graphics.*

/**
 * RentalContractRenderer: محرك رسم عقد إيجار الدور والأراضي السكنية
 * مطابق بنسبة 100% للصورة الأصلية مع كافة البنود والإحداثيات.
 */
class RentalContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? RentalContract ?: RentalContract()

        val margin = 50f
        val fullWidth = A4_WIDTH - (margin * 2)

        // 1. صور العقارات والأيقونة في أعلى الترويسة
        val leftHouseRect = RectF(margin, 50f, margin + 200f, 180f)
        val rightLogoRect = RectF(A4_WIDTH - margin - 180f, 50f, A4_WIDTH - margin, 180f)
        drawOptionalHeaderImage(canvas, context, "ic_rental_header_left", leftHouseRect)
        drawOptionalHeaderImage(canvas, context, "ic_rental_header_right", rightLogoRect)

        // رقم العقد
        val noPaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
            isAntiAlias = true
        }
        canvas.drawText("No: ${data.contractNo.ifEmpty { "1024" }}", margin, 210f, noPaint)

        // بيانات المكتب والترويسة الرسمية
        val officeNameText = officeInfo.officeName.ifEmpty { "مكتب السلام للعقارات والسيارات" }
        val officePhoneText = "هاتف: ${officeInfo.phone.ifEmpty { "07700000000" }}"

        val officeNamePaint = Paint().apply {
            color = Color.parseColor("#0F172A") // كحلي داكن فاخر
            textSize = 32f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val officePhonePaint = Paint().apply {
            color = COLOR_PRIMARY
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText(officeNameText, A4_WIDTH / 2f, 75f, officeNamePaint)
        canvas.drawText(officePhoneText, A4_WIDTH / 2f, 105f, officePhonePaint)

        // العنوان الرئيسي
        val redTitlePaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 42f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val subTitlePaint = Paint().apply {
            color = COLOR_PRIMARY
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText("عقــد ايجــار", A4_WIDTH / 2f, 145f, redTitlePaint)
        canvas.drawText("بيع وشراء الدور والاراضي السكنية", A4_WIDTH / 2f, 178f, subTitlePaint)

        var currentY = 240f

        // 2. عدد التسلسل ورقم الأبواب
        val col2Width = fullWidth / 2f
        drawFieldWithDots(canvas, "عدد التسلسل :", data.sequenceNumber, A4_WIDTH - margin, currentY, col2Width)
        drawFieldWithDots(canvas, "رقم الابواب :", data.doorsNumber, A4_WIDTH - margin - col2Width, currentY, col2Width)
        currentY += 52f

        // تم العقد بين
        drawFieldWithDots(canvas, "تم العقد بين :", data.lessorName, A4_WIDTH - margin, currentY, fullWidth - 220f)
        val lessorSuffix = "المدعو فيما يلي بالمؤجر"
        canvas.drawText(lessorSuffix, margin + 200f, currentY, bodyTextPaint)
        currentY += 52f

        // المستأجر
        drawFieldWithDots(canvas, "             ", data.lesseeName, A4_WIDTH - margin, currentY, fullWidth - 220f)
        val lesseeSuffix = "المدعو فيما يلي بالمستأجر"
        canvas.drawText(lesseeSuffix, margin + 200f, currentY, bodyTextPaint)
        currentY += 52f

        // على ما يلي :
        canvas.drawText("على ما يلي :", A4_WIDTH - margin, currentY, labelPaint)
        currentY += 50f

        // أولا : ان المؤجر قد أجر الى المستأجر
        val text1 = "اولا : ان المؤجر قد أجر الى المستأجر وهذا قد استأجر بعد الرؤية والاطلاع على"
        canvas.drawText(text1, A4_WIDTH - margin, currentY, bodyTextPaint)
        val text1W = bodyTextPaint.measureText(text1)
        drawFieldWithDots(canvas, "", data.rentedPropertyDescription, A4_WIDTH - margin - text1W, currentY, fullWidth - text1W)
        currentY += 52f

        // الواقع | في المحلة | زقاق | لمدة
        val col4Width = fullWidth / 4f
        drawFieldWithDots(canvas, "الواقع :", data.propertyLocation, A4_WIDTH - margin, currentY, col4Width)
        drawFieldWithDots(canvas, "في المحلة :", data.neighborhood, A4_WIDTH - margin - col4Width, currentY, col4Width)
        drawFieldWithDots(canvas, "زقاق :", data.alleyNumber, A4_WIDTH - margin - (col4Width * 2), currentY, col4Width)
        drawFieldWithDots(canvas, "لمدة :", data.leaseDuration, A4_WIDTH - margin - (col4Width * 3), currentY, col4Width)
        currentY += 52f

        // ابتداء من
        drawFieldWithDots(canvas, "ابتداءً من :", data.startDate, A4_WIDTH - margin, currentY, fullWidth)
        currentY += 54f

        // الى نهاية
        drawFieldWithDots(canvas, "إلى نهاية :", data.endDate, A4_WIDTH - margin, currentY, fullWidth)
        currentY += 54f

        // بدل ايجار فقط
        drawFieldWithDots(canvas, "ببدل إيجار فقط :", data.rentAmountWords, A4_WIDTH - margin, currentY, fullWidth)
        currentY += 58f

        // ثانيا : ان المؤجر قد أجر
        val text2 = "ثانياً : أن المؤجر قد أجر "
        canvas.drawText(text2, A4_WIDTH - margin, currentY, bodyTextPaint)
        val text2W = bodyTextPaint.measureText(text2)
        val suffix2 = " العائد إلى المستأجر إليه ببدل إيجار ."
        val suffix2W = bodyTextPaint.measureText(suffix2)
        drawFieldWithDots(canvas, "", data.returnToLesseeText, A4_WIDTH - margin - text2W, currentY, fullWidth - text2W - suffix2W)
        canvas.drawText(suffix2, margin + suffix2W, currentY, bodyTextPaint)
        currentY += 58f

        // ثالثا : للمستأجر حق السكن
        val text3 = "ثالثاً : للمستأجر حق السكن "
        canvas.drawText(text3, A4_WIDTH - margin, currentY, bodyTextPaint)
        val text3W = bodyTextPaint.measureText(text3)
        val mid3 = " في المأجور مدة الإيجار "
        val mid3W = bodyTextPaint.measureText(mid3)
        drawFieldWithDots(canvas, "", data.dwellingRightDetails, A4_WIDTH - margin - text3W, currentY, fullWidth - text3W - mid3W - 150f)
        canvas.drawText(mid3, margin + 200f, currentY, bodyTextPaint)
        drawFieldWithDots(canvas, "", data.leaseDuration, margin + 200f - mid3W, currentY, 150f)
        currentY += 52f

        canvas.drawText("وعند ختام مدة الإيجار فإن المستأجر ملزم بتخلية المأجور وتسليمه إلى المؤجر خالياً من الشواغل وإذا تأخر عن ذلك فيكون ملزماً بأن يدفع عن مدة التأخير", A4_WIDTH - margin, currentY, bodyTextPaint)
        currentY += 52f

        drawFieldWithDots(canvas, "إيجار يومي قدره :", data.dailyDelayFee, A4_WIDTH - margin, currentY, fullWidth - 250f)
        canvas.drawText("من غير حاجة إلى إنذار رسمي", margin + 240f, currentY, bodyTextPaint)
        currentY += 58f

        // رابعا : ان ضريبة الاملاك
        val text4 = "رابعاً : أن ضريبة الأملاك على المؤجر أو صاحب "
        canvas.drawText(text4, A4_WIDTH - margin, currentY, bodyTextPaint)
        val text4W = bodyTextPaint.measureText(text4)
        drawFieldWithDots(canvas, "", data.propertyTaxOwner, A4_WIDTH - margin - text4W, currentY, fullWidth - text4W - 400f)
        val text4End = " ورسوم الماء والكهرباء والتنظيف فهي"
        canvas.drawText(text4End, margin + 390f, currentY, bodyTextPaint)
        currentY += 52f

        canvas.drawText("على المستأجر يدفعها منتظماً من خالص ماله علاوة على بدل الإيجار المحرر أعلاه وإبراز الوصولات إلى المؤجر عند الطلب وعليه أن يسلم كافة", A4_WIDTH - margin, currentY, bodyTextPaint)
        currentY += 52f

        canvas.drawText("المصابيح الكهربائية والزجاج والمؤسسات الأخرى المذكورة في هذه الورقة سالمة كما استلمها .", A4_WIDTH - margin, currentY, bodyTextPaint)
        currentY += 58f

        val signDateText = "كتبت على نسختين بيد كل من الفريقين نسخة واحدة في    /    / 20"
        canvas.drawText(signDateText, A4_WIDTH - margin, currentY, bodyTextPaint)
        currentY += 58f

        // فقرات إضافية
        drawFieldWithDots(canvas, "فقرات إضافية :", data.additionalClauses, A4_WIDTH - margin, currentY, fullWidth)

        // 3. مربع الأختام وبصمات الإبهام
        val stampY = currentY + 25f
        val stampHeight = 110f
        val stampWidth = (fullWidth - 40f) / 3f

        val stampBoxPaint = Paint().apply {
            color = COLOR_BG_LIGHT
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val stampBorderPaint = Paint().apply {
            color = COLOR_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 1f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            isAntiAlias = true
        }
        val stampTextPaint = Paint().apply {
            color = COLOR_LABEL
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightStamp = RectF(A4_WIDTH - margin - stampWidth, stampY, A4_WIDTH - margin, stampY + stampHeight)
        val middleStamp = RectF(A4_WIDTH - margin - (stampWidth * 2) - 20f, stampY, A4_WIDTH - margin - stampWidth - 20f, stampY + stampHeight)
        val leftStamp = RectF(margin, stampY, margin + stampWidth, stampY + stampHeight)

        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة إبهام المؤجر", rightStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("ختم وتوقيع المكتب", middleStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة إبهام المستأجر", leftStamp.centerX(), stampY + 65f, stampTextPaint)

        // 4. التواقيع
        drawSignatures(
            canvas = canvas,
            titles = listOf("توقيع المؤجر", "الشاهد الأول", "الشاهد الثاني", "توقيع المستأجر"),
            bottomY = A4_HEIGHT - 65f
        )
    }
}
