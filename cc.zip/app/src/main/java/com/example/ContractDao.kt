package com.example

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ContractDao {
    @Query("SELECT * FROM saved_contracts ORDER BY dateCreated DESC")
    fun getAllContracts(): Flow<List<ContractEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContract(contract: ContractEntity): Long

    @Query("DELETE FROM saved_contracts WHERE id = :id")
    suspend fun deleteContractById(id: Long)

    @Query("SELECT * FROM saved_contracts WHERE id = :id")
    suspend fun getContractById(id: Long): ContractEntity?
}
