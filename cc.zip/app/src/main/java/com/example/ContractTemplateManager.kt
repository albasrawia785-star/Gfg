package com.example

import android.content.Context
import android.graphics.Bitmap

/**
 * نموذج مواصفات وقالب العقد (Contract Template)
 */
data class ContractTemplate(
    val contractType: ContractType,
    val title: String,
    val subtitle: String,
    val headerImageAssetLeft: String = "",
    val headerImageAssetRight: String = "",
    val primaryColorHex: String = "#0F172A", // كحلي فاخر
    val secondaryColorHex: String = "#1E3A8A" // أزرق رسمي
)

/**
 * مدير قوالب ورسامات العقود (ContractTemplateManager)
 * المسؤول عن:
 * - تحميل قالب العقد والجهات الرسومية الخاصة به.
 * - إرجاع الـ BaseContractRenderer الخاص بالعقد.
 * - تحويل بيانات أي عقد إلى Bitmap جاهز للطباعة أو المعاينة.
 * - توفير معمارية مرنة تتيح إضافة عقد جديد في المستقبل بإنشاء Data Class و Renderer فقط دون تعديل أي ملف أساسي آخر.
 */
object ContractTemplateManager {

    private val templates = mapOf(
        ContractType.REAL_ESTATE to ContractTemplate(
            contractType = ContractType.REAL_ESTATE,
            title = "عقد بيع وشراء عقار",
            subtitle = "الدور والاراضي السكنية والزراعية",
            headerImageAssetLeft = "ic_real_estate_left",
            headerImageAssetRight = "ic_real_estate_right"
        ),
        ContractType.CAR_SALE to ContractTemplate(
            contractType = ContractType.CAR_SALE,
            title = "عقد بيع وشراء السيارات",
            subtitle = "لتجارة السيارات الحديثة",
            headerImageAssetLeft = "ic_car_header_left",
            headerImageAssetRight = "ic_car_header_right"
        ),
        ContractType.RENTAL to ContractTemplate(
            contractType = ContractType.RENTAL,
            title = "عقد ايجار",
            subtitle = "بيع وشراء الدور والاراضي السكنية",
            headerImageAssetLeft = "ic_rental_header_left",
            headerImageAssetRight = "ic_rental_header_right"
        ),
        ContractType.MOTORCYCLE to ContractTemplate(
            contractType = ContractType.MOTORCYCLE,
            title = "عقد بيع وشراء",
            subtitle = "الدراجات والتكتك والستوتات",
            headerImageAssetLeft = "ic_motorcycle_header_left",
            headerImageAssetRight = "ic_motorcycle_header_right"
        )
    )

    private val renderers = mapOf<ContractType, BaseContractRenderer>(
        ContractType.REAL_ESTATE to RealEstateContractRenderer(),
        ContractType.CAR_SALE to CarSaleContractRenderer(),
        ContractType.RENTAL to RentalContractRenderer(),
        ContractType.MOTORCYCLE to MotorcycleContractRenderer()
    )

    /**
     * الحصول على قالب العقد
     */
    fun getTemplate(contractType: ContractType): ContractTemplate {
        return templates[contractType] ?: ContractTemplate(
            contractType = contractType,
            title = contractType.titleAr,
            subtitle = "استمارة عقد رسمية معتمدة"
        )
    }

    /**
     * الحصول على محرك الرسم الخاص بنوع العقد
     */
    fun getRenderer(contractType: ContractType): BaseContractRenderer {
        return renderers[contractType] ?: RealEstateContractRenderer()
    }

    /**
     * رسم ورقة العقد بحجم A4
     */
    fun renderContractBitmap(
        contractType: ContractType,
        contractData: Any,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        val renderer = getRenderer(contractType)
        return renderer.renderBitmap(contractData, officeInfo, context)
    }
}
