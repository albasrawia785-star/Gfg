package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * الواجهة الرئيسية المحدثة والمطابقة للتصميم المطلوب بالكامل
 * تتضمن كروت ملونة كبيرة 2x2 للأنواع الأربعة وكروت سفلية للخدمات المساندة
 * بدون أي أزرار تنبيهات أو خطوط قائمة جانبية في الأعلى حسب الطلب.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreenUi(
    onSelectRealEstate: () -> Unit,
    onSelectCarSale: () -> Unit,
    onSelectRental: () -> Unit,
    onSelectMotorcycle: () -> Unit,
    onSelectSavedContracts: () -> Unit,
    onSelectPrinter: () -> Unit,
    onSelectSettings: () -> Unit,
    onMenuClick: () -> Unit = {},
    onNotificationClick: () -> Unit = {},
    savedContractsCount: Int = 0
) {
    val topBarBg = Color(0xFF0F387A) // الأزرق الملكي الداكن للشريط العلوي
    val pageBg = Color(0xFFF8FAFC)   // خلفية الصفحة الفاتحة المريحة للعين

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(pageBg)
    ) {
        // الشريط العلوي مع عنوان محاذى للوسط بدون أزرار قائمة أو تنبيهات
        CenterAlignedTopAppBar(
            title = {
                Text(
                    text = "الرئيسية",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = topBarBg
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // قسم الترحيب العلوي
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "مرحباً بك في",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "عقود برو",
                fontSize = 34.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF0F387A)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "اختر نوع العقد",
                fontSize = 16.sp,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(28.dp))

            // شبكة كروت العقود 2x2
            // السطر الأول: بيع سيارة | بيع عقار
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // عقد بيع سيارة (أخضر)
                MainContractGridCard(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_car_sale"),
                    title = "عقد بيع سيارة",
                    icon = Icons.Default.DirectionsCar,
                    cardBgColor = Color(0xFF059669),
                    onClick = onSelectCarSale
                )

                // عقد بيع عقار (أزرق)
                MainContractGridCard(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_real_estate"),
                    title = "عقد بيع عقار",
                    icon = Icons.Default.HomeWork,
                    cardBgColor = Color(0xFF0284C7),
                    onClick = onSelectRealEstate
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // السطر الثاني: دراجة/تكتك | عقد إيجار
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // عقد دراجة / تكتك (كحلي داكن)
                MainContractGridCard(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_motorcycle"),
                    title = "عقد دراجة / تكتك",
                    icon = Icons.Default.TwoWheeler,
                    cardBgColor = Color(0xFF1E293B),
                    onClick = onSelectMotorcycle
                )

                // عقد إيجار (بنفسجي / إنديجو)
                MainContractGridCard(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_rental"),
                    title = "عقد إيجار",
                    icon = Icons.Default.Apartment,
                    cardBgColor = Color(0xFF5B50E6),
                    onClick = onSelectRental
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // السطر السفي: كروت صغيرة بيضاء للأدوات (الإعدادات | الطباعة | العقود المحفوظة)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // كارت الإعدادات
                BottomActionCard(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_settings"),
                    title = "الإعدادات",
                    icon = Icons.Outlined.Settings,
                    onClick = onSelectSettings
                )

                // كارت الطباعة
                BottomActionCard(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_printer"),
                    title = "الطباعة",
                    icon = Icons.Outlined.Print,
                    onClick = onSelectPrinter
                )

                // كارت العقود المحفوظة
                BottomActionCard(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_saved_contracts"),
                    title = "العقود المحفوظة",
                    icon = Icons.Outlined.Description,
                    onClick = onSelectSavedContracts
                )
            }



            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

/**
 * كارت رئيسي ملون لشبكة العقود 2x2
 */
@Composable
private fun MainContractGridCard(
    modifier: Modifier = Modifier,
    title: String,
    icon: ImageVector,
    cardBgColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(145.dp)
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(22.dp),
                spotColor = cardBgColor.copy(alpha = 0.4f)
            )
            .clickable { onClick() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color.White,
                modifier = Modifier.size(46.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                color = Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }
    }
}

/**
 * كارت أداة أبيض مصغر بالسطر السفلي
 */
@Composable
private fun BottomActionCard(
    modifier: Modifier = Modifier,
    title: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(110.dp)
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color.Black.copy(alpha = 0.1f)
            )
            .clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        contentColor = Color(0xFF1E293B)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color(0xFF1E293B),
                modifier = Modifier.size(32.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = title,
                color = Color(0xFF1E293B),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
        }
    }
}
