package com.example

/**
 * نتيجة التحقق من صحة حقل أو عقد معين
 */
data class ValidationResult(
    val isValid: Boolean,
    val errors: Map<String, String> = emptyMap() // Map of field key to error message
) {
    fun getError(fieldKey: String): String? = errors[fieldKey]
    fun hasError(fieldKey: String): Boolean = errors.containsKey(fieldKey)
}

object ContractValidation {

    /**
     * التحقق من رقم البطاقة الوطنية (يجب أن يتكون من 12 رقماً)
     */
    fun validateNationalId(idNumber: String, fieldName: String = "رقم البطاقة الوطنية"): String? {
        val trimmed = idNumber.trim()
        if (trimmed.isEmpty()) return null // اختياري إن لم يكن إجبارياً، أو يطلب إدخاله
        val digitsOnly = trimmed.filter { it.isDigit() }
        return if (digitsOnly.length != 12) {
            "$fieldName يجب أن يتكون من 12 رقماً (الحالي: ${digitsOnly.length})"
        } else {
            null
        }
    }

    /**
     * التحقق من رقم الهاتف (يجب أن يتكون من 11 رقماً)
     */
    fun validatePhone(phone: String, fieldName: String = "رقم الهاتف"): String? {
        val trimmed = phone.trim()
        if (trimmed.isEmpty()) return null
        val digitsOnly = trimmed.filter { it.isDigit() }
        return if (digitsOnly.length != 11) {
            "$fieldName يجب أن يتكون من 11 رقماً (مثال: 07700000000)"
        } else {
            null
        }
    }

    /**
     * التحقق من المبلغ المالي
     */
    fun validateAmount(amount: String, fieldName: String = "المبلغ"): String? {
        val trimmed = amount.trim()
        if (trimmed.isEmpty()) return null
        val cleanString = trimmed.replace(",", "").replace(".", "").replace(" ", "").filter { it.isDigit() }
        return if (cleanString.isEmpty()) {
            "$fieldName غير صحيح"
        } else {
            null
        }
    }

    /**
     * التحقق الشامل لعقد بيع وشراء الدراجات والتكتك
     */
    fun validateMotorcycleContract(contract: MotorcycleContract): ValidationResult {
        val errors = mutableMapOf<String, String>()

        // أسماء الأطراف
        if (contract.sellerName.isBlank()) {
            errors["sellerName"] = "يرجى كتابة اسم البائع الثلاثي"
        }
        if (contract.buyerName.isBlank()) {
            errors["buyerName"] = "يرجى كتابة اسم المشتري الثلاثي"
        }

        // أرقام البطاقة الوطنية
        validateNationalId(contract.sellerIdNumber, "بطاقة البائع")?.let { errors["sellerIdNumber"] = it }
        validateNationalId(contract.buyerIdNumber, "بطاقة المشتري")?.let { errors["buyerIdNumber"] = it }
        if (contract.possessorIdNumber.isNotBlank()) {
            validateNationalId(contract.possessorIdNumber, "بطاقة الحائز")?.let { errors["possessorIdNumber"] = it }
        }

        // أرقام الهواتف
        validatePhone(contract.sellerPhone, "هاتف البائع")?.let { errors["sellerPhone"] = it }
        validatePhone(contract.buyerPhone, "هاتف المشتري")?.let { errors["buyerPhone"] = it }
        if (contract.possessorPhone.isNotBlank()) {
            validatePhone(contract.possessorPhone, "هاتف الحائز")?.let { errors["possessorPhone"] = it }
        }

        // المبالغ
        validateAmount(contract.totalPrice, "السعر الكلي")?.let { errors["totalPrice"] = it }
        validateAmount(contract.paidAmount, "المبلغ المقبوض")?.let { errors["paidAmount"] = it }
        validateAmount(contract.remainingAmount, "المبلغ المتبقي")?.let { errors["remainingAmount"] = it }

        return ValidationResult(isValid = errors.isEmpty(), errors = errors)
    }

    /**
     * التحقق الشامل لعقد بيع وشراء السيارات
     */
    fun validateCarSaleContract(contract: CarSaleContract): ValidationResult {
        val errors = mutableMapOf<String, String>()

        if (contract.sellerName.isBlank()) {
            errors["sellerName"] = "يرجى كتابة اسم البائع"
        }
        if (contract.buyerName.isBlank()) {
            errors["buyerName"] = "يرجى كتابة اسم المشتري"
        }

        validateNationalId(contract.sellerIdNumber, "بطاقة البائع")?.let { errors["sellerIdNumber"] = it }
        validateNationalId(contract.buyerIdNumber, "بطاقة المشتري")?.let { errors["buyerIdNumber"] = it }

        validatePhone(contract.sellerPhone, "هاتف البائع")?.let { errors["sellerPhone"] = it }
        validatePhone(contract.buyerPhone, "هاتف المشتري")?.let { errors["buyerPhone"] = it }

        validateAmount(contract.totalPrice, "بدل البيع")?.let { errors["totalPrice"] = it }
        validateAmount(contract.paidAmount, "المبلغ المستلم")?.let { errors["paidAmount"] = it }
        validateAmount(contract.remainingAmount, "المبلغ المتبقي")?.let { errors["remainingAmount"] = it }

        return ValidationResult(isValid = errors.isEmpty(), errors = errors)
    }

    /**
     * التحقق الشامل لعقد بيع وشراء العقارات
     */
    fun validateRealEstateContract(contract: RealEstateContract): ValidationResult {
        val errors = mutableMapOf<String, String>()

        if (contract.sellerName.isBlank()) {
            errors["sellerName"] = "يرجى كتابة اسم البائع"
        }
        if (contract.buyerName.isBlank()) {
            errors["buyerName"] = "يرجى كتابة اسم المشتري"
        }

        validateNationalId(contract.sellerIdNumber, "بطاقة البائع")?.let { errors["sellerIdNumber"] = it }
        validateNationalId(contract.buyerIdNumber, "بطاقة المشتري")?.let { errors["buyerIdNumber"] = it }

        validatePhone(contract.sellerPhone, "هاتف البائع")?.let { errors["sellerPhone"] = it }
        validatePhone(contract.buyerPhone, "هاتف المشتري")?.let { errors["buyerPhone"] = it }

        validateAmount(contract.totalPrice, "بدل البيع")?.let { errors["totalPrice"] = it }
        validateAmount(contract.depositPrice, "العربون")?.let { errors["depositPrice"] = it }
        validateAmount(contract.remainingPrice, "المبلغ المتبقي")?.let { errors["remainingPrice"] = it }

        return ValidationResult(isValid = errors.isEmpty(), errors = errors)
    }

    /**
     * التحقق الشامل لعقد الإيجار
     */
    fun validateRentalContract(contract: RentalContract): ValidationResult {
        val errors = mutableMapOf<String, String>()

        if (contract.lessorName.isBlank()) {
            errors["lessorName"] = "يرجى كتابة اسم المؤجر"
        }
        if (contract.lesseeName.isBlank()) {
            errors["lesseeName"] = "يرجى كتابة اسم المستأجر"
        }

        validateAmount(contract.rentAmountNumber, "بدل الإيجار")?.let { errors["rentAmountNumber"] = it }

        return ValidationResult(isValid = errors.isEmpty(), errors = errors)
    }
}
