package com.example

import android.content.Context
import android.graphics.*

/**
 * CarSaleContractRenderer: محرك رسم عقد بيع وشراء السيارات (معارض السيارات)
 * مطابق بنسبة 100% للصورة الأصلية مع كافة التفاصيل والإحداثيات.
 */
class CarSaleContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? CarSaleContract ?: CarSaleContract()

        val margin = 50f
        val fullWidth = A4_WIDTH - (margin * 2)

        // 1. مربع الترويسة العلوي المعنون
        val headerBoxRect = RectF(margin, 50f, A4_WIDTH - margin, 210f)
        val headerBoxBorder = Paint().apply {
            color = COLOR_PRIMARY
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(headerBoxRect, 10f, 10f, headerBoxBorder)

        // صور السيارات على الجانبين
        val leftCarRect = RectF(margin + 10f, 60f, margin + 200f, 160f)
        val rightCarRect = RectF(A4_WIDTH - margin - 200f, 60f, A4_WIDTH - margin - 10f, 160f)
        drawOptionalHeaderImage(canvas, context, "ic_car_header_left", leftCarRect)
        drawOptionalHeaderImage(canvas, context, "ic_car_header_right", rightCarRect)

        // نصوص الترويسة المركزية
        val galleryName = if (data.galleryName.isNotBlank()) data.galleryName else officeInfo.officeName.ifEmpty { "معرض السيارات" }
        val galleryNamePaint = Paint().apply {
            color = Color.parseColor("#047857") // أخضر المعارض الفاخر
            textSize = 42f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val subHeaderPaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val contractTitlePaint = Paint().apply {
            color = COLOR_PRIMARY
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText(galleryName, A4_WIDTH / 2f, 100f, galleryNamePaint)
        canvas.drawText("لتجارة السيارات الحديثة", A4_WIDTH / 2f, 135f, subHeaderPaint)
        canvas.drawText("عقد بيع وشراء السيارات", A4_WIDTH / 2f, 165f, contractTitlePaint)

        // شريط العنوان والهاتف الملون في أسفل مربع الترويسة
        val stripRect = RectF(headerBoxRect.left, headerBoxRect.bottom - 35f, headerBoxRect.right, headerBoxRect.bottom)
        val stripBg = Paint().apply {
            color = Color.parseColor("#047857")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRect(stripRect, stripBg)

        val stripTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val phoneText = "موبايل: ${if (data.galleryPhone.isNotBlank()) data.galleryPhone else officeInfo.phone}"
        val addressText = "العنوان / ${if (data.galleryAddress.isNotBlank()) data.galleryAddress else officeInfo.address}"

        stripTextPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(phoneText, stripRect.left + 20f, stripRect.centerY() + 6f, stripTextPaint)

        stripTextPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(addressText, stripRect.right - 20f, stripRect.centerY() + 6f, stripTextPaint)

        // 2. رقم العقد والمالك الشرعي
        var currentY = 235f
        val noPaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val noText = "№  ${data.contractNo.ifEmpty { "000100" }}"
        canvas.drawText(noText, A4_WIDTH - margin, currentY, noPaint)

        currentY += 35f
        val ownerName = data.carLegalOwner.ifEmpty { "" }
        val ownerAddress = data.ownerAddress.ifEmpty { "" }
        drawFieldWithDots(canvas, "المالك الشرعي للسيارة :", ownerName, A4_WIDTH - margin, currentY, fullWidth * 0.55f)
        drawFieldWithDots(canvas, "عنوانه :", ownerAddress, A4_WIDTH - margin - (fullWidth * 0.55f), currentY, fullWidth * 0.45f)

        // 3. مربعي الطرف الأول والطرف الثاني
        currentY += 35f
        val boxHeight = 220f
        val (rightBox, leftBox) = drawSideBySidePartyBoxes(
            canvas = canvas,
            topY = currentY,
            boxHeight = boxHeight,
            rightTitle = "الطرف الأول ( البائع )",
            leftTitle = "الطرف الثاني ( المشتري )"
        )

        // محتوى البائع
        var rY = rightBox.top + 55f
        val rRight = rightBox.right - 15f
        val rWidth = rightBox.width() - 30f
        drawFieldWithDots(canvas, "البائع السيد:", data.sellerName, rRight, rY, rWidth)
        rY += 36f
        drawFieldWithDots(canvas, "السكن:", data.sellerAddress, rRight, rY, rWidth)
        rY += 36f
        drawFieldWithDots(canvas, "المعرف بالهوية المرقمة:", data.sellerIdNumber, rRight, rY, rWidth)
        rY += 36f
        drawFieldWithDots(canvas, "موبايل:", data.sellerPhone, rRight, rY, rWidth)

        // محتوى المشتري
        var lY = leftBox.top + 55f
        val lRight = leftBox.right - 15f
        val lWidth = leftBox.width() - 30f
        drawFieldWithDots(canvas, "المشتري السيد:", data.buyerName, lRight, lY, lWidth)
        lY += 36f
        drawFieldWithDots(canvas, "السكن:", data.buyerAddress, lRight, lY, lWidth)
        lY += 36f
        drawFieldWithDots(canvas, "المعرف بالهوية المرقمة:", data.buyerIdNumber, lRight, lY, lWidth)
        lY += 36f
        drawFieldWithDots(canvas, "موبايل:", data.buyerPhone, lRight, lY, lWidth)

        // 4. مواصفات المركبة والبدل المالي
        currentY += boxHeight + 40f
        val redHeaderPaint = Paint().apply {
            color = COLOR_RED_ACCENT
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        // أولاً - باع الطرف الأول إلى الطرف الثاني السيارة المرقمة
        val regText = "أولاً - باع الطرف الأول الى الطرف الثاني السيارة المرقمة : "
        canvas.drawText(regText, A4_WIDTH - margin, currentY, redHeaderPaint)
        val regTextWidth = redHeaderPaint.measureText(regText)
        drawFieldWithDots(canvas, "", data.annualRegNumber, A4_WIDTH - margin - regTextWidth, currentY, fullWidth - regTextWidth - 180f)

        val catText = "خصوصي - اجرة - حمل"
        canvas.drawText(catText, margin + 170f, currentY, bodyTextPaint)
        currentY += 44f

        // نوع السيارة | موديل | اللون
        val col3Width = fullWidth / 3f
        drawFieldWithDots(canvas, "نوع السيارة :", data.carBrandAndType, A4_WIDTH - margin, currentY, col3Width)
        drawFieldWithDots(canvas, "موديل :", data.modelYear, A4_WIDTH - margin - col3Width, currentY, col3Width)
        drawFieldWithDots(canvas, "اللون :", data.color, A4_WIDTH - margin - (col3Width * 2), currentY, col3Width)
        currentY += 44f

        // رقم السنوية | رقم المحرك
        val col2Width = fullWidth / 2f
        drawFieldWithDots(canvas, "رقم السنوية :", data.annualRegNumber, A4_WIDTH - margin, currentY, col2Width)
        drawFieldWithDots(canvas, "رقم المحرك :", data.engineNumber, A4_WIDTH - margin - col2Width, currentY, col2Width)
        currentY += 44f

        // رقم الشاسي
        drawFieldWithDots(canvas, "رقم الشاسي :", data.chassisNumber, A4_WIDTH - margin, currentY, fullWidth)
        currentY += 44f

        // ببدل قدره | كتابةً
        drawFieldWithDots(canvas, "ببدل قدره :", data.totalPrice, A4_WIDTH - margin, currentY, fullWidth * 0.45f)
        drawFieldWithDots(canvas, "كتابةً :", data.totalPriceWords, A4_WIDTH - margin - (fullWidth * 0.45f), currentY, fullWidth * 0.55f)
        currentY += 44f

        // وقد استلم البائع مبلغ قدره
        drawFieldWithDots(canvas, "وقد استلم البائع مبلغ قدره :", data.paidAmount, A4_WIDTH - margin, currentY, fullWidth)
        currentY += 44f

        // والباقي قدره
        drawFieldWithDots(canvas, "والباقي قدره :", data.remainingAmount, A4_WIDTH - margin, currentY, fullWidth)
        currentY += 50f

        // 5. البنود والشروط القانونية
        val clauses = listOf(
            Pair("ثانياً - ", "استلم الطرف الثاني المركبة أعلاه وهو المسؤول عنها من تاريخ هذا العقد."),
            Pair("ثالثاً - ", "الطرف الأول مسؤول عن دفع كافة الغرامات والرسوم المترتبة ورفع الحجوزات إن وجدت لغاية تاريخ هذا العقد."),
            Pair("رابعاً - ", "على المشتري فحص السيارة قبل الشراء، والمكتب غير مسؤول بتاتاً عن أية عيوب خفية بعد التسليم."),
            Pair("خامساً - ", "قبلت السيارة على كل عيب فيها للطرفين، والمكتب غير مسؤول عن أي اتفاق شفهي ثاني."),
            Pair("سادساً - ", "كل عقد غير مختوم بختم المعرض الرسمي وصادر بغير رقم تسلسل يعتبر باطلاً ولا يُعتد به."),
            Pair("سابعاً - ", "يلتزم البائع والمشتري بتحويل ملكية المركبة خلال ٣٠ يوماً من تاريخ العقد، وبعكسه يتحمل الطرف المقصر كافة الإجراءات القانونية.")
        )

        for (clause in clauses) {
            canvas.drawText(clause.first, A4_WIDTH - margin, currentY, redHeaderPaint)
            val prefixW = redHeaderPaint.measureText(clause.first)
            canvas.drawText(clause.second, A4_WIDTH - margin - prefixW, currentY, bodyTextPaint)
            currentY += 38f
        }

        currentY += 15f
        val dateText = "حرر بتاريخ    /    / 202   كتابةً"
        val greenDatePaint = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(dateText, A4_WIDTH - margin, currentY, greenDatePaint)

        // 6. مربع بصمات الأختام
        val stampY = currentY + 25f
        val stampHeight = 110f
        val stampWidth = (fullWidth - 40f) / 3f

        val stampBoxPaint = Paint().apply {
            color = COLOR_BG_LIGHT
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val stampBorderPaint = Paint().apply {
            color = COLOR_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 1f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            isAntiAlias = true
        }
        val stampTextPaint = Paint().apply {
            color = COLOR_LABEL
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightStamp = RectF(A4_WIDTH - margin - stampWidth, stampY, A4_WIDTH - margin, stampY + stampHeight)
        val middleStamp = RectF(A4_WIDTH - margin - (stampWidth * 2) - 20f, stampY, A4_WIDTH - margin - stampWidth - 20f, stampY + stampHeight)
        val leftStamp = RectF(margin, stampY, margin + stampWidth, stampY + stampHeight)

        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة إبهام البائع", rightStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("ختم المعرض والتوقيع", middleStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة إبهام المشتري", leftStamp.centerX(), stampY + 65f, stampTextPaint)

        // 7. التواقيع
        drawSignatures(
            canvas = canvas,
            titles = listOf("الطرف الأول (البائع)", "الشهود", "منظم العقد", "الطرف الثاني (المشتري)"),
            bottomY = A4_HEIGHT - 65f
        )
    }
}
